import json
from pathlib import Path
import uuid
import boto3 

s3_client = boto3.client("s3")
upload_bucket = "syargpt-media-bucket"

def render_diagram(code_block): 

    file_name = f"{uuid.uuid4()}"
    file_path = f"/tmp/{file_name}"   
    print(file_path)
    code_block = code_block.replace("show=False", f"show=False, filename='{file_path}'")
    print(code_block)
    # replace ./resources with absolute path
    code_block = code_block.replace("./resources", str(Path(__file__).parent / "resources"))
    print(code_block)
    exec(code_block)
    
    # upload diagram to s3
    s3_file_name = f"{file_name}.png"
    s3_client.upload_file(f"{file_path}.png", upload_bucket, s3_file_name)
    
    return f"https://{upload_bucket}.s3.us-west-2.amazonaws.com/{file_name}.png"
    


def lambda_handler(event, context):
    if event.get("body"):
        event = json.loads(event["body"])
        
    print(f"Received event: {json.dumps(event)}")
    print(json.loads(json.dumps(event)))
    
    code_block = event["code_block"]
    image = render_diagram(code_block)
    
    return {
        "statusCode": 200,
        "body": json.dumps({
            "image": image
        }),
    }
    
if __name__ == "__main__":
    # Test the lambda function
    event = {
        "code_block": """
        
from pathlib import Path

print(Path.cwd())
   
from diagrams import Cluster, Diagram
from diagrams.aws.analytics import Athena
from diagrams.aws.database import DynamodbTable, Dynamodb
from diagrams.aws.integration import EventbridgeDefaultEventBusResource, Eventbridge
from diagrams.aws.compute import Lambda
from diagrams.aws.storage import SimpleStorageServiceS3Bucket, S3
from diagrams.custom import Custom
with Diagram("PDF AI Chat Architecture", show=False):
    with Cluster("AWS Infrastructure"):
        pdf_bucket = SimpleStorageServiceS3Bucket("PDF Bucket")
        text_chunks_bucket = SimpleStorageServiceS3Bucket("Text Chunks Bucket")
        vector_db = DynamodbTable("Vector Database")

        pdf_processing = Lambda("PDF Processing")
        chat_handler = Lambda("Chat Handler")

        events = EventbridgeDefaultEventBusResource("Events")

        bedrock_embedding = Custom("Bedrock Embedding API", "E:/Personal/VPBank-challenge/resources/bedrock.png")
        bedrock_chat = Custom("Bedrock Chat API", "./resources/bedrock.png")

        pdf_bucket >> pdf_processing >> events
        events >> chat_handler

        chat_handler >> bedrock_embedding >> vector_db
        chat_handler >> text_chunks_bucket
        chat_handler >> bedrock_chat

        athena = Athena("Query Vector DB")
        vector_db >> athena >> chat_handler
"""
    }
    
    response = lambda_handler(event, None)
    print(response)